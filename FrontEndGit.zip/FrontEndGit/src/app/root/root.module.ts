import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NbSidebarModule, NbLayoutModule, NbSidebarService, NbCardModule } from '@nebular/theme';
import { RootComponent } from './root.component';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RootComponent,
    NbSidebarModule,
    NbLayoutModule,
    NbSidebarService,
    NbCardModule
  ],
  providers: [NbSidebarService]
})
export class RootModule { }
