import { Component, OnInit } from '@angular/core';
import { RootService } from './root.service';

@Component({
  selector: 'app-selector',
  templateUrl: './root.component.html',
  styleUrls: ['../../styles.scss']
})
export class RootComponent implements OnInit {

  constructor(private rootService : RootService) { }

  ngOnInit() {
    /*
    this.rootService.getAPIData().subscribe((response) => {
      console.log('response is ', response)
    },(error) => {
      console.log('error is ', error)
    })

    this.rootService.postAPIData().subscribe((response)=>{
      console.log('response from post data is ', response);
    },(error)=>{
      console.log('error during post is ', error)
    })
    */
  }

  postData(){
    this.rootService.postAPIDataSelection().subscribe((response)=>{
      console.log('response from post data is ', response);
    },(error)=>{
      console.log('error during post is ', error)
    })
  }

  postDatasimple(){
    this.rootService.postAPIData().subscribe((response)=>{
      console.log('response from post data is ', response);
    },(error)=>{
      console.log('error during post is ', error)
    })
  }

  getDataregular(){
    this.rootService.getdatareg().subscribe((response)=>{
      console.log('response from post data is ', response);
    },(error)=>{
      console.log('error during post is ', error)
    })
  }

  getmoreData(){
    this.rootService.getAPIData().subscribe((response) => {
      console.log('response is ', response)
    },(error) => {
      console.log('error is ', error)
    })
  }
}
