import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RootService {

  constructor(private http: HttpClient) { }

  getdatareg(){
    return this.http.get('api/');
  }

  getAPIData(){
    return this.http.get('https://jsonplaceholder.typicode.com/users');
  }

  postAPIData1(){
      return this.http.post('/api/postData', {'firstName' : 'Code', 'lastName' : 'Handbook'})
  }

  postAPIData(){
    return this.http.post('/api/postData', {'device_ID':'sonoff_37c89d','device_type': 'sonoff', 'command':'set_power_state', 'value':'1'});
  }

  postAPIDataSelection(){
    return this.http.post('/api/postDataSelection', {})
  }
}
