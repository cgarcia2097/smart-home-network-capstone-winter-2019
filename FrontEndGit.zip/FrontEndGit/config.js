let config = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'sensor'
};

module.exports = config;
