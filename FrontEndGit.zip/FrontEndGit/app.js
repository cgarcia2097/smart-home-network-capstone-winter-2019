const express = require('express');
const app = express();
const bodyParser = require('body-parser');
let mysql = require('mysql');
let config = require('./config.js');
var http = require("http");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())

app.get('/', (req, res) => {
	//res.send('Welcome to Node API');
	res.json({'message': 'Hello World'});
})

app.get('/getData', (req, res) => {
	res.json({'message': 'Hello World'});
	console.log("hi");
})
//send muh message to http
app.post('/postData', bodyParser.json(), (req, res) => {
	console.log("hi2");
	var data = req.body;
	console.log(req.body);
	var options = {
	  "method": "POST",
	  "hostname": "localhost",
	  "port": "8080",
	  "headers": {
	    "Content-Type": "application/json"
			//"Content-Length": data.length
	  }
	};

	const req1 = http.request(options, (res1) => {
  	console.log(`statusCode: ${res1.statusCode}`);
  	res1.on('data', (d) => {
    process.stdout.write(d);
  	})
	})

	req1.on('error', (error) => {
  	console.error(error);
	})

	req1.write(JSON.stringify(data));
	req1.end();

	res.json(req.body);
	console.log(req.body);
})

app.post('/postDataSelection', bodyParser.json(), (req, res) => {
	console.log(req.body);
	let sql = `SELECT * FROM sensorData`;
	let connection = mysql.createConnection(config);

	connection.query(sql, (error, results, fields) => {
	  if (error) {
	    return console.error(error.message);
	  }
	  res.send(results);
	});
	console.log('results sent bruv');
	connection.end();
});

app.listen(3000, () => console.log('Example app listening on port 3000!'))

